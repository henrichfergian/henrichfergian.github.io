# football-score
a PWA Web-App that provide information about football, competitions, matches, and teams
